package FeatureWait;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class HotelManagement {
	static WebDriver driver;
	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "D:\\c\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("file://ndafile/Shared%20Materials/GLC-G102/BDD/Selenium/hotelbooking.html");
		
		driver.findElement(By.id("txtFirstName")).sendKeys("");
		callAlert();
		driver.findElement(By.id("txtFirstName")).sendKeys("kavita");
		
		driver.findElement(By.id("txtLastName")).sendKeys("");
		callAlert();
		driver.findElement(By.id("txtLastName")).sendKeys("sharma");
		
		driver.findElement(By.id("txtEmail")).sendKeys("");
		callAlert();
		driver.findElement(By.id("txtEmail")).sendKeys("kavita4797@gmail.com");
		
		driver.findElement(By.id("txtPhone")).sendKeys("");
		callAlert();
		driver.findElement(By.id("txtPhone")).sendKeys("9997026135");
		driver.findElement(By.xpath("html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")).sendKeys("");
		callAlert();
		driver.findElement(By.xpath("html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")).sendKeys("TalwadeRoad");
	
		Select drpCity = new Select(driver.findElement(By.name("city")));
		drpCity.selectByIndex(1);
		callAlert();
		
		drpCity.selectByIndex(1);
		Select drpState = new Select(driver.findElement(By.name("state")));
		drpState.selectByIndex(0);
		callAlert();
		
		drpState.selectByIndex(1);
		Select drpPerson = new Select(driver.findElement(By.name("persons")));
		drpPerson.selectByIndex(0);
		callAlert();
		
		
		drpPerson.selectByIndex(2);
		driver.findElement(By.id("txtCardholderName")).sendKeys("");
		callAlert();
		driver.findElement(By.id("txtCardholderName")).sendKeys("97026135");
		
		driver.findElement(By.id("txtDebit")).sendKeys("");
		callAlert();
		driver.findElement(By.id("txtDebit")).sendKeys("9702135");
		
		driver.findElement(By.id("txtCvv")).sendKeys("");
		callAlert();
		driver.findElement(By.id("txtCvv")).sendKeys("9135");
		
		driver.findElement(By.id("txtMonth")).sendKeys("");
		callAlert();
		driver.findElement(By.id("txtMonth")).sendKeys("3");
		
		
		driver.findElement(By.id("txtYear")).sendKeys("");
		callAlert();
		driver.findElement(By.id("txtYear")).sendKeys("2019");
		driver.findElement(By.id("btnPayment")).click();
		
		driver.quit();
		driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}']")).sendKeys("9810960585");
		driver.findElement(By.id("btnPayment")).click();
		callAlert();
		
		driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}'")).clear();
		driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}']")).sendKeys("9810960585");
		
		
		Select drpCity = new Select(driver.findElement(By.name("city")));
		drpCity.selectByIndex(1);
		
	}
	
	
	public static void callAlert() throws InterruptedException {
		driver.findElement(By.id("btnPayment")).click();
		String alertMessage=driver.switchTo().alert().getText();
		System.out.println(alertMessage);
		Thread.sleep(100);
		driver.switchTo().alert().accept();
		Thread.sleep(100);

	}

}
