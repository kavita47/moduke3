package formFeaturefile;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefForfEATUREfILE {
	WebDriver driver;
	@Given("^Open the Firefox and launch the application$")
	public void open_the_Firefox_and_launch_the_application() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\c\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("file://ndafile/Shared%20Materials/GLC-G102/BDD/WorkingWithForms.html");
		
	}

	@When("^Enter the Username,Password,Confirm Password,First Name,Last Name,Gender,Date of Birth,Email,Address,City,Phone and Hobbies$")
	public void enter_the_Username_Password_Confirm_Password_First_Name_Last_Name_Gender_Date_of_Birth_Email_Address_City_Phone_and_Hobbies() throws Throwable {
		driver.findElement(By.id("txtUserName")).sendKeys("kavita123");
		//Thread.sleep(1000);
		
		driver.findElement(By.name("txtPwd")).sendKeys("igate");
		
		driver.findElement(By.className("Format")).sendKeys("igate");
		
	
	driver.findElement(By.cssSelector("input.Format1")).sendKeys("kavita1");
	driver.findElement(By.name("txtLN")).sendKeys("kavita2");
	
	driver.findElement(By.cssSelector("input[value='Female']")).click();
	
	driver.findElement(By.name("DtOB")).sendKeys("04/07/1997");
	
	driver.findElement(By.name("Email")).sendKeys("kavi4797@gmail.com");
	
	driver.findElement(By.name("Address")).sendKeys("keshav Puram");
	
	Select drpCity= new Select(driver.findElement(By.name("City")));
	
	drpCity.selectByIndex(1);
	
	driver.findElement(By.xpath(".//*[@id='txtPhone']")).sendKeys("9997026135");
	driver.findElement(By.cssSelector("input[value='Reading']")).click();
	driver.findElement(By.cssSelector("input[value='Music']")).click();
	}

	@Then("^Reset the credential$")
	public void reset_the_credential() throws Throwable {

		driver.findElement(By.xpath(".//*[@id='myStyle']")).click();
	}



}
