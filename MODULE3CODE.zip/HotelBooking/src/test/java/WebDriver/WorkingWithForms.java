package WebDriver;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class WorkingWithForms {
	public static void main(String args[]) throws InterruptedException
	{
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "D:\\c\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("file://ndafile/Shared%20Materials/GLC-G102/BDD/WorkingWithForms.html");
		try {
		//Find Username textboxXCV and enter value
		driver.findElement(By.id("txtUserName")).sendKeys("kavita123");
		//Thread.sleep(1000);
		
		driver.findElement(By.name("txtPwd")).sendKeys("igate");
		
		driver.findElement(By.className("Format")).sendKeys("igate");
		
	
	driver.findElement(By.cssSelector("input.Format1")).sendKeys("kavita1");
	driver.findElement(By.name("txtLN")).sendKeys("kavita2");
	
	driver.findElement(By.cssSelector("input[value='Female']")).click();
	
	driver.findElement(By.name("DtOB")).sendKeys("04/07/1997");
	
	driver.findElement(By.name("Email")).sendKeys("kavi4797@gmail.com");
	
	driver.findElement(By.name("Address")).sendKeys("keshav Puram");
	
	Select drpCity= new Select(driver.findElement(By.name("City")));
	
	drpCity.selectByIndex(1);
	
	driver.findElement(By.xpath(".//*[@id='txtPhone']")).sendKeys("9997026135");
	driver.findElement(By.cssSelector("input[value='Reading']")).click();
	driver.findElement(By.cssSelector("input[value='Music']")).click();
	//List<WebElement> element=driver.findElement(By.name("kavita33"));
	
	/*{
		val.click();
		try {
			Thread.sleep(1000);
		}catch(InterruptedException ex)
	
	}*/
	
	driver.findElement(By.xpath(".//*[@id='myStyle']")).click();

	}catch (Exception e) {System.out.println("some exception");

		
	}
	}
}

