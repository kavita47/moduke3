package com.cg.hotelloginsuccess;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.bean.*;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {
	private WebDriver driver;
	private Beans obj;
	private BeansLogin obj1;

	@Given("^User is on hotel login page$")
	public void user_is_on_hotel_login_page() throws Throwable {
		Thread.sleep(1000);
		System.setProperty("webdriver.chrome.driver", "D:\\c\\chromedriver.exe");
		driver=new ChromeDriver();
		Thread.sleep(1000);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		obj1 = new BeansLogin(driver);
		driver.get("file:///D:/Users/KAVITASH/Desktop/login.html");

	}

	@When("^user leaves userName blank$")
	public void user_leaves_userName_blank() throws Throwable {
		obj1.setPffname("");
		Thread.sleep(1000);
	}

	@When("^clicks the button$")
	public void clicks_the_button() throws Throwable {
		obj1.setPfbutton();

	}

	@Then("^display msg$")
	public void display_msg() throws Throwable {
		System.out.println(driver.findElement(By.id("userErrMsg")).getText());
		Thread.sleep(1000);
		driver.close();

	}

	@When("^user leaves password blank and clicks the button$")
	public void user_leaves_password_blank_and_clicks_the_button() throws Throwable {
		obj1.setPffname("capgemini");
		Thread.sleep(1000);
		obj1.setPass("");
		Thread.sleep(1000);
		obj1.setPfbutton();
		System.out.println(driver.findElement(By.id("pwdErrMsg")).getText());

	}

	@When("^user enters incorrect userName or password and click the button$")
	public void user_enters_incorrect_userName_or_password_and_click_the_button() throws Throwable {
		obj1.setPffname("Capgemini");
		Thread.sleep(1000);
		obj1.setPass("Himan");
		Thread.sleep(1000);
		obj1.setPfbutton();
		
	}
 // this is the alert message code 
	@Then("^display alert msg$")
	public void display_alert_msg() throws Throwable {
		String alertmessage = driver.switchTo().alert().getText();
		System.out.println("The alert message is:" + alertmessage);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
		driver.close();
	}

	@When("^user enters all valid data$")
	public void user_enters_all_valid_data() throws Throwable {
		obj1.setPffname("capgemini");
		Thread.sleep(1000);
		obj1.setPass("capg1234");
		Thread.sleep(5000);
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);

		obj1.setPfbutton();
	}

	@Then("^navigate to welcome page$")
	public void navigate_to_welcome_page() throws Throwable {
		driver.navigate().to("file:///D:/Users/KAVITASH/Desktop/hotelbooking.html");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		Thread.sleep(1000);
		driver.close();
	}

	@Given("^User is on hotel booking page$")
	public void user_is_on_hotel_booking_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\c\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		obj = new Beans(driver);
		driver.get("file:///D:/Users/KAVITASH/Desktop/hotelbooking.html");

	}

	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
		Thread.sleep(1000);
		String title = driver.getTitle();
		if (title.contentEquals("Hotel Booking"))
			System.out.println("****** Title Matched");
		else
			System.out.println("****** Title NOT Matched");
		Thread.sleep(4000);
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		driver.close();
	}

	@When("^user enters all valid datahotel$")
	public void user_enters_all_valid_datahotel() throws Throwable {
		obj.setPffname("Himanshu");
		Thread.sleep(1000);
		obj.setPflname("Mishra");
		Thread.sleep(1000);
		obj.setPfemail("himanshumishra536@gmail.com");
		Thread.sleep(1000);
		obj.setPfmobile("9598526348");
		Thread.sleep(1000);
		obj.setPfcity("Chennai");
		Thread.sleep(1000);
		obj.setPfstate("Maharashtra");
		Thread.sleep(1000);
		obj.setPfpersons("5");
		Thread.sleep(1000);
		obj.setPfcardholder("Himanshu");
		Thread.sleep(1000);
		obj.setPfdebit("45781578956348");
		Thread.sleep(1000);
		obj.setPfcvv("067");
		Thread.sleep(1000);
		obj.setPfmonth("5");
		Thread.sleep(1000);
		obj.setPfyear("2020");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		obj.setPfbutton();
		
	}
    // this is for navigating to different page 
	@Then("^navigate to welcome pagesucces$")
	public void navigate_to_welcome_pagesucces() throws Throwable {
		driver.navigate().to("file:///D:/Users/KAVITASH/Desktop/success.html");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		Thread.sleep(1000);
		driver.close();

	}
     // this will be according to the question 
	@When("^user leaves first Name blank$")
	public void user_leaves_first_Name_blank() throws Throwable {
		obj.setPffname("");
		Thread.sleep(1000);

	}
    // clicking the button 
	@When("^clicks the buttonhotel$")
	public void clicks_the_buttonhotel() throws Throwable {
		obj.setPfbutton();
	}

	@Then("^display alert msghotel$")
	public void display_alert_msghotel() throws Throwable {
		String alertmessage = driver.switchTo().alert().getText();
		System.out.println("The alert message is:" + alertmessage);
		driver.switchTo().alert().accept();

	}

	@When("^user leaves last Name blank and clicks the button$")
	public void user_leaves_last_Name_blank_and_clicks_the_button() throws Throwable {
		obj.setPffname("Himanshu");
		Thread.sleep(1000);
		obj.setPflname("");
		Thread.sleep(1000);
		obj.setPfbutton();
	}

	@When("^user enters all data$")
	public void user_enters_all_data() throws Throwable {
		obj.setPffname("Himanshu");
		Thread.sleep(1000);
		obj.setPflname("Mishra");
		Thread.sleep(1000);
		obj.setPfmobile("9598526348");
		Thread.sleep(1000);
		obj.setPfcity("Chennai");
		Thread.sleep(1000);
		obj.setPfstate("Maharashtra");
		Thread.sleep(1000);
		obj.setPfpersons("5");
		Thread.sleep(1000);
		obj.setPfcardholder("Himanshu Mishra");
		Thread.sleep(1000);
		obj.setPfdebit("45781248459652");
		Thread.sleep(1000);
		obj.setPfcvv("056");
		Thread.sleep(1000);
		obj.setPfmonth("9");
		Thread.sleep(1000);
		obj.setPfyear("2020");
		Thread.sleep(1000);
	}

	@When("^user enters incorrect email format and clicks the button$")
	public void user_enters_incorrect_email_format_and_clicks_the_button() throws Throwable {
		obj.setPfemail("him@.com");
		Thread.sleep(1000);
		obj.setPfbutton();
	}

	@When("^user leaves MobileNo blank and clicks the button$")
	public void user_leaves_MobileNo_blank_and_clicks_the_button() throws Throwable {
		obj.setPffname("Himanshu");
		Thread.sleep(1000);
		obj.setPflname("Mishra");
		Thread.sleep(1000);
		obj.setPfemail("himanshumishra536@gmail.com");
		Thread.sleep(1000);
		obj.setPfmobile("");
		Thread.sleep(1000);
		obj.setPfbutton();
	}

	@When("^user enters incorrect mobileNo format and clicks the button$")
	public void user_enters_incorrect_mobileNo_format_and_clicks_the_button() throws Throwable {
		obj.setPffname("Himanshu");
		Thread.sleep(1000);
		obj.setPflname("Mishra");
		Thread.sleep(1000);
		obj.setPfemail("himanshumishra536@gmail.com");
		Thread.sleep(1000);
		obj.setPfmobile("111111");
		Thread.sleep(1000);
		obj.setPfbutton();
	}

	@When("^user doesnot select city$")
	public void user_doesnot_select_city() throws Throwable {
		obj.setPffname("Himanshu");
		Thread.sleep(1000);
		obj.setPflname("Mishra");
		Thread.sleep(1000);
		obj.setPfemail("himanshumishra536@gmail.com");
		Thread.sleep(1000);
		obj.setPfmobile("9598526348");
		Thread.sleep(1000);
		obj.setPfcity("Select City");
		Thread.sleep(1000);
		obj.setPfbutton();
	}

	@When("^user doesnot select state$")
	public void user_doesnot_select_state() throws Throwable {
		obj.setPffname("Himanshu");
		Thread.sleep(1000);
		obj.setPflname("Mishra");
		Thread.sleep(1000);
		obj.setPfemail("himanshumishra536@gmail.com");
		Thread.sleep(1000);
		obj.setPfmobile("9598526348");
		Thread.sleep(1000);
		obj.setPfcity("Pune");
		Thread.sleep(1000);
		obj.setPfstate("Select State");
		Thread.sleep(1000);
		obj.setPfbutton();
	}

	@When("^user leaves CardHolderName blank and clicks the button$")
	public void user_leaves_CardHolderName_blank_and_clicks_the_button() throws Throwable {
		obj.setPffname("Himanshu");
		Thread.sleep(1000);
		obj.setPflname("Mishra");
		Thread.sleep(1000);
		obj.setPfemail("himanshumishra536@gmail.com");
		Thread.sleep(1000);
		obj.setPfmobile("9598526348");
		Thread.sleep(1000);
		obj.setPfcity("Pune");
		Thread.sleep(1000);
		obj.setPfstate("Maharashtra");
		Thread.sleep(1000);
		obj.setPfpersons("7");
		Thread.sleep(1000);
		obj.setPfcardholder("");
		Thread.sleep(1000);
		obj.setPfbutton();
	}

	@When("^user leaves DebitCardNo blank and clicks the button$")
	public void user_leaves_DebitCardNo_blank_and_clicks_the_button() throws Throwable {
		obj.setPffname("Himanshu");
		Thread.sleep(1000);
		obj.setPflname("Mishra");
		Thread.sleep(1000);
		obj.setPfemail("himanshumishra536@gmail.com");
		Thread.sleep(1000);
		obj.setPfmobile("9598526348");
		Thread.sleep(1000);
		obj.setPfcity("Pune");
		Thread.sleep(1000);
		obj.setPfstate("Maharashtra");
		Thread.sleep(1000);
		obj.setPfpersons("7");
		Thread.sleep(1000);
		obj.setPfcardholder("Himanshu Mishra");
		Thread.sleep(1000);
		obj.setPfdebit("");
		Thread.sleep(1000);
		obj.setPfbutton();
	}

	@When("^user leaves CVV blank and clicks the button$")
	public void user_leaves_CVV_blank_and_clicks_the_button() throws Throwable {
		obj.setPffname("Himanshu");
		Thread.sleep(1000);
		obj.setPflname("Mishra");
		Thread.sleep(1000);
		obj.setPfemail("himanshumishra536@gmail.com");
		Thread.sleep(1000);
		obj.setPfmobile("9598526348");
		Thread.sleep(1000);
		obj.setPfcity("Pune");
		Thread.sleep(1000);
		obj.setPfstate("Maharashtra");
		Thread.sleep(1000);
		obj.setPfpersons("7");
		Thread.sleep(1000);
		obj.setPfcardholder("Himanshu Mishra");
		Thread.sleep(1000);
		obj.setPfdebit("5412785246");
		Thread.sleep(1000);
		obj.setPfcvv("");
		Thread.sleep(1000);
		obj.setPfbutton();
	}

	@When("^user leaves expirationMonth blank and clicks the button$")
	public void user_leaves_expirationMonth_blank_and_clicks_the_button() throws Throwable {
		obj.setPffname("Himanshu");
		Thread.sleep(1000);
		obj.setPflname("Mishra");
		Thread.sleep(1000);
		obj.setPfemail("himanshumishra536@gmail.com");
		Thread.sleep(1000);
		obj.setPfmobile("7722005480");
		Thread.sleep(1000);
		obj.setPfcity("Pune");
		Thread.sleep(1000);
		obj.setPfstate("Maharashtra");
		Thread.sleep(1000);
		obj.setPfpersons("7");
		Thread.sleep(1000);
		obj.setPfcardholder("Himanshu Mishra");
		Thread.sleep(1000);
		obj.setPfdebit("5412785246");
		Thread.sleep(1000);
		obj.setPfcvv("522");
		Thread.sleep(1000);
		obj.setPfmonth("");
		Thread.sleep(1000);
		obj.setPfbutton();
	}

	@When("^user leaves expirationYr blank and clicks the button$")
	public void user_leaves_expirationYr_blank_and_clicks_the_button() throws Throwable {
		obj.setPffname("Himanshu");
		Thread.sleep(1000);
		obj.setPflname("Mishra");
		Thread.sleep(1000);
		obj.setPfemail("himanshumishra536@gmail.com");
		Thread.sleep(1000);
		obj.setPfmobile("9598526348");
		Thread.sleep(1000);
		obj.setPfcity("Pune");
		Thread.sleep(1000);
		obj.setPfstate("Maharashtra");
		Thread.sleep(1000);
		obj.setPfpersons("7");
		Thread.sleep(1000);
		obj.setPfcardholder("Himanshu Mishra");
		Thread.sleep(1000);
		obj.setPfdebit("5412785246");
		Thread.sleep(1000);
		obj.setPfcvv("522");
		Thread.sleep(1000);
		obj.setPfmonth("8");
		Thread.sleep(1000);
		obj.setPfyear("");
		Thread.sleep(1000);
		obj.setPfbutton();
	}

}
